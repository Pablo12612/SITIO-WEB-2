let inputActivo = "num1";

// Detecta qué input está activo
document.getElementById("num1").addEventListener("focus", () => {
    inputActivo = "num1";
});

document.getElementById("num2").addEventListener("focus", () => {
    inputActivo = "num2";
});

function agregarNumero(numero) {
    let input = document.getElementById(inputActivo);
    input.value += numero;
}

function obtenerValores() {
    let n1 = parseFloat(document.getElementById("num1").value) || 0;
    let n2 = parseFloat(document.getElementById("num2").value) || 0;
    return { n1, n2 };
}

function sumar() {
    const { n1, n2 } = obtenerValores();
    mostrarResultado(n1 + n2);
}

function restar() {
    const { n1, n2 } = obtenerValores();
    mostrarResultado(n1 - n2);
}

function multiplicar() {
    const { n1, n2 } = obtenerValores();
    mostrarResultado(n1 * n2);
}

function dividir() {
    const { n1, n2 } = obtenerValores();
    if (n2 === 0) {
        alert("No se puede dividir entre 0");
        return;
    }
    mostrarResultado(n1 / n2);
}

function mostrarResultado(resultado) {
    document.getElementById("resultado").textContent = resultado;
}
